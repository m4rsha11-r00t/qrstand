'use strict';

const Database = require('better-sqlite3');
const crypto   = require('crypto');
const path     = require('path');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'qrstand.db');
const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ─── Base schema ───────────────────────────────────────────────────────────────

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT    NOT NULL,
    email         TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    is_admin      INTEGER NOT NULL DEFAULT 0,
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS stands (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    activation_code TEXT    NOT NULL UNIQUE,
    user_id         INTEGER REFERENCES users(id) ON DELETE SET NULL,
    redirect_url    TEXT,
    status          TEXT    NOT NULL DEFAULT 'unactivated',
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    activated_at    DATETIME
  );

  CREATE INDEX IF NOT EXISTS idx_stands_activation_code ON stands(activation_code);
  CREATE INDEX IF NOT EXISTS idx_stands_user_id         ON stands(user_id);
  CREATE INDEX IF NOT EXISTS idx_stands_status          ON stands(status);
`);

// ─── Migrations ────────────────────────────────────────────────────────────────

const standsColumns = db.pragma('table_info(stands)').map(c => c.name);

if (!standsColumns.includes('token')) {
  db.exec('ALTER TABLE stands ADD COLUMN token TEXT');
}

if (!standsColumns.includes('batch_name')) {
  db.exec('ALTER TABLE stands ADD COLUMN batch_name TEXT');
}

// Create indexes that depend on migrated columns
db.exec(`
  CREATE INDEX IF NOT EXISTS idx_stands_token      ON stands(token);
  CREATE INDEX IF NOT EXISTS idx_stands_batch_name ON stands(batch_name);
`);

// Back-fill any stands missing a token
const untokenised = db.prepare('SELECT id FROM stands WHERE token IS NULL').all();
if (untokenised.length > 0) {
  const backfill = db.prepare('UPDATE stands SET token = ? WHERE id = ?');
  db.transaction(() => {
    for (const row of untokenised) {
      backfill.run(crypto.randomBytes(8).toString('hex'), row.id);
    }
  })();
}

module.exports = db;

'use strict';

require('dotenv').config();

const express  = require('express');
const session  = require('express-session');
const flash    = require('connect-flash');
const path     = require('path');

// Initialise DB (runs schema on first boot)
require('./database/db');

const app = express();

// ─── View engine ───────────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ─── Middleware ────────────────────────────────────────────────────────────────
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret:            process.env.SESSION_SECRET || 'change-me-in-production',
  resave:            false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    maxAge:   7 * 24 * 60 * 60 * 1000, // 7 days
    secure:   process.env.NODE_ENV === 'production' && process.env.APP_URL?.startsWith('https'),
  },
}));

app.use(flash());

// Make flash messages and current user available in all views
app.use((req, res, next) => {
  res.locals.success  = req.flash('success');
  res.locals.error    = req.flash('error');
  res.locals.user     = req.session.user || null;
  res.locals.appUrl   = process.env.APP_URL || 'http://localhost:3000';
  next();
});

// ─── Routes ────────────────────────────────────────────────────────────────────
app.use('/',       require('./routes/scan'));
app.use('/',       require('./routes/auth'));
app.use('/',       require('./routes/stands'));
app.use('/admin',  require('./routes/admin'));

// ─── 404 handler ──────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).render('404');
});

// ─── Error handler ────────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('500');
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`QR Stand running on port ${PORT} [${process.env.NODE_ENV || 'development'}]`);
});

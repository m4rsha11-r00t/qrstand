'use strict';

require('dotenv').config();

const express   = require('express');
const session   = require('express-session');
const flash     = require('connect-flash');
const morgan    = require('morgan');
const rateLimit = require('express-rate-limit');
const path      = require('path');

// ─── Safety check ──────────────────────────────────────────────────────────────
if (process.env.NODE_ENV === 'production' && !process.env.SESSION_SECRET) {
  console.error('FATAL: SESSION_SECRET must be set in production.');
  process.exit(1);
}

// Initialise DB (runs schema + migrations on first boot)
require('./database/db');

const app = express();

// ─── View engine ───────────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ─── Request logging ───────────────────────────────────────────────────────────
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ─── Rate limiting ─────────────────────────────────────────────────────────────
const authLimiter = rateLimit({
  windowMs:         15 * 60 * 1000, // 15 minutes
  max:              15,
  standardHeaders:  true,
  legacyHeaders:    false,
  message:          'Too many attempts. Please try again in 15 minutes.',
  handler: (req, res, next, options) => {
    req.flash('error', options.message);
    const route = req.path === '/login' ? '/login' : '/register';
    res.redirect(route);
  },
});

// ─── Core middleware ───────────────────────────────────────────────────────────
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret:            process.env.SESSION_SECRET || 'change-me-in-development',
  resave:            false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    maxAge:   7 * 24 * 60 * 60 * 1000,
    secure:   process.env.NODE_ENV === 'production' && process.env.APP_URL?.startsWith('https'),
  },
}));

app.use(flash());

app.use((req, res, next) => {
  res.locals.success = req.flash('success');
  res.locals.error   = req.flash('error');
  res.locals.user    = req.session.user || null;
  res.locals.appUrl  = process.env.APP_URL || 'http://localhost:3000';
  next();
});

// ─── Health check ──────────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', uptime: Math.floor(process.uptime()) });
});

// ─── Routes ────────────────────────────────────────────────────────────────────
app.use('/',      require('./routes/scan'));
app.use('/',      authLimiter, require('./routes/auth'));
app.use('/',      require('./routes/stands'));
app.use('/',      require('./routes/join'));
app.use('/admin', require('./routes/admin'));

// ─── 404 handler ──────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).render('404', { title: 'Not found' });
});

// ─── Error handler ────────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('500');
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`QR Stand running on port ${PORT} [${process.env.NODE_ENV || 'development'}]`);
});

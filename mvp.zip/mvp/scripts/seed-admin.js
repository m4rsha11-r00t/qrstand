'use strict';

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const bcrypt = require('bcryptjs');
const db     = require('../database/db');

const name     = process.env.ADMIN_NAME;
const email    = process.env.ADMIN_EMAIL;
const password = process.env.ADMIN_PASSWORD;

if (!name || !email || !password) {
  console.error('ERROR: ADMIN_NAME, ADMIN_EMAIL, and ADMIN_PASSWORD must be set in .env');
  process.exit(1);
}

if (password.length < 12) {
  console.error('ERROR: ADMIN_PASSWORD must be at least 12 characters.');
  process.exit(1);
}

const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase());

if (existing) {
  console.log(`Admin already exists: ${email}`);
  process.exit(0);
}

const hash = bcrypt.hashSync(password, 12);

db.prepare(
  'INSERT INTO users (name, email, password_hash, is_admin) VALUES (?, ?, ?, 1)'
).run(name, email.toLowerCase(), hash);

console.log(`Admin created: ${email}`);

'use strict';

const express = require('express');
const QRCode  = require('qrcode');
const db      = require('../database/db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// ─── Dashboard ────────────────────────────────────────────────────────────────

router.get('/dashboard', requireAuth, (req, res) => {
  const stands = db.prepare(
    'SELECT * FROM stands WHERE user_id = ? ORDER BY activated_at DESC'
  ).all(req.session.user.id);

  res.render('dashboard/index', {
    title:  'My Stands',
    stands,
    appUrl: process.env.APP_URL || 'http://localhost:3000',
  });
});

// ─── Activate ─────────────────────────────────────────────────────────────────
// ?token= is set when the user arrives via a stand's unique QR scan.
// It pre-identifies the stand so the user only needs to enter the activation
// code (printed under the stand) and their destination URL.

router.get('/activate', requireAuth, (req, res) => {
  res.render('dashboard/activate', {
    title: 'Activate Stand',
    token: req.query.token || '',
  });
});

router.post('/activate', requireAuth, (req, res) => {
  const { activation_code, redirect_url, token } = req.body;
  const returnUrl = token ? `/activate?token=${token}` : '/activate';

  if (!activation_code?.trim()) {
    req.flash('error', 'Activation code is required.');
    return res.redirect(returnUrl);
  }

  if (!redirect_url?.trim()) {
    req.flash('error', 'Redirect URL is required.');
    return res.redirect(returnUrl);
  }

  try {
    const url = new URL(redirect_url.trim());
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error();
  } catch {
    req.flash('error', 'Please enter a valid URL starting with http:// or https://');
    return res.redirect(returnUrl);
  }

  const stand = db.prepare(
    'SELECT * FROM stands WHERE activation_code = ?'
  ).get(activation_code.trim().toUpperCase());

  if (!stand) {
    req.flash('error', 'Invalid activation code. Please check and try again.');
    return res.redirect(returnUrl);
  }

  // If a token was passed (QR scan), verify it matches this stand
  if (token && stand.token !== token) {
    req.flash('error', 'That activation code does not belong to the stand you scanned.');
    return res.redirect(returnUrl);
  }

  if (stand.status === 'active' || stand.user_id) {
    req.flash('error', 'This activation code has already been used.');
    return res.redirect(returnUrl);
  }

  db.prepare(`
    UPDATE stands
    SET user_id      = ?,
        redirect_url = ?,
        status       = 'active',
        activated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(req.session.user.id, redirect_url.trim(), stand.id);

  req.flash('success', 'Stand activated successfully! Your QR code is ready.');
  res.redirect('/dashboard');
});

// ─── Edit redirect URL ────────────────────────────────────────────────────────

router.get('/stands/:id/edit', requireAuth, (req, res) => {
  const stand = db.prepare(
    'SELECT * FROM stands WHERE id = ? AND user_id = ?'
  ).get(req.params.id, req.session.user.id);

  if (!stand) return res.status(404).render('404', { title: 'Not found' });

  res.render('dashboard/edit', { title: 'Edit Stand', stand });
});

router.post('/stands/:id', requireAuth, (req, res) => {
  const { redirect_url, _method } = req.body;
  const method = _method?.toUpperCase();

  if (method === 'DELETE') {
    const stand = db.prepare(
      'SELECT id FROM stands WHERE id = ? AND user_id = ?'
    ).get(req.params.id, req.session.user.id);

    if (!stand) return res.status(404).render('404', { title: 'Not found' });

    db.prepare("UPDATE stands SET status = 'disabled' WHERE id = ?").run(stand.id);
    req.flash('success', 'Stand disabled.');
    return res.redirect('/dashboard');
  }

  // PUT — update redirect URL
  if (!redirect_url?.trim()) {
    req.flash('error', 'Redirect URL is required.');
    return res.redirect(`/stands/${req.params.id}/edit`);
  }

  try {
    const url = new URL(redirect_url.trim());
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error();
  } catch {
    req.flash('error', 'Please enter a valid URL starting with http:// or https://');
    return res.redirect(`/stands/${req.params.id}/edit`);
  }

  const stand = db.prepare(
    'SELECT id FROM stands WHERE id = ? AND user_id = ?'
  ).get(req.params.id, req.session.user.id);

  if (!stand) return res.status(404).render('404', { title: 'Not found' });

  db.prepare('UPDATE stands SET redirect_url = ? WHERE id = ?')
    .run(redirect_url.trim(), stand.id);

  req.flash('success', 'Redirect URL updated.');
  res.redirect('/dashboard');
});

// ─── QR code download (per-stand, user-facing) ────────────────────────────────
// Generates a QR encoding APP_URL/s/:token — unique per stand.

router.get('/stands/:id/qr', requireAuth, async (req, res) => {
  const stand = db.prepare(
    'SELECT id, token FROM stands WHERE id = ? AND user_id = ?'
  ).get(req.params.id, req.session.user.id);

  if (!stand) return res.status(404).render('404', { title: 'Not found' });

  const standUrl = `${process.env.APP_URL || 'http://localhost:3000'}/s/${stand.token}`;
  try {
    const png = await QRCode.toBuffer(standUrl, {
      type:                 'png',
      width:                1200,
      margin:               2,
      errorCorrectionLevel: 'H',
      color: { dark: '#000000', light: '#FFFFFF' },
    });

    res.set({
      'Content-Type':        'image/png',
      'Content-Disposition': `attachment; filename="stand-${stand.id}-qr.png"`,
      'Cache-Control':       'no-store',
    });
    res.send(png);
  } catch (err) {
    console.error('QR generation failed:', err);
    req.flash('error', 'QR code generation failed.');
    res.redirect('/dashboard');
  }
});

module.exports = router;

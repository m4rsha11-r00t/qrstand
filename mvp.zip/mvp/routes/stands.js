'use strict';

const express = require('express');
const QRCode  = require('qrcode');
const db      = require('../database/db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// ─── Dashboard ────────────────────────────────────────────────────────────────

router.get('/dashboard', requireAuth, (req, res) => {
  const stands = db.prepare(
    'SELECT * FROM stands WHERE user_id = ? ORDER BY activated_at DESC'
  ).all(req.session.user.id);

  res.render('dashboard/index', {
    title:  'My Stands',
    stands,
    appUrl: process.env.APP_URL || 'http://localhost:3000',
  });
});

// ─── Activate ─────────────────────────────────────────────────────────────────

router.get('/activate', requireAuth, (req, res) => {
  res.render('dashboard/activate', { title: 'Activate Stand' });
});

router.post('/activate', requireAuth, (req, res) => {
  const { activation_code, redirect_url } = req.body;

  if (!activation_code?.trim()) {
    req.flash('error', 'Activation code is required.');
    return res.redirect('/activate');
  }

  if (!redirect_url?.trim()) {
    req.flash('error', 'Redirect URL is required.');
    return res.redirect('/activate');
  }

  // Basic URL validation
  try {
    const url = new URL(redirect_url.trim());
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error();
  } catch {
    req.flash('error', 'Please enter a valid URL starting with http:// or https://');
    return res.redirect('/activate');
  }

  const stand = db.prepare(
    'SELECT * FROM stands WHERE activation_code = ?'
  ).get(activation_code.trim().toUpperCase());

  if (!stand) {
    req.flash('error', 'Invalid activation code. Please check and try again.');
    return res.redirect('/activate');
  }

  if (stand.status === 'active' || stand.user_id) {
    req.flash('error', 'This activation code has already been used.');
    return res.redirect('/activate');
  }

  db.prepare(`
    UPDATE stands
    SET user_id      = ?,
        redirect_url = ?,
        status       = 'active',
        activated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(req.session.user.id, redirect_url.trim(), stand.id);

  req.flash('success', 'Stand activated successfully! Your QR code is ready.');
  res.redirect('/dashboard');
});

// ─── Edit redirect URL ────────────────────────────────────────────────────────

router.get('/stands/:id/edit', requireAuth, (req, res) => {
  const stand = db.prepare(
    'SELECT * FROM stands WHERE id = ? AND user_id = ?'
  ).get(req.params.id, req.session.user.id);

  if (!stand) return res.status(404).render('404');

  res.render('dashboard/edit', { title: 'Edit Stand', stand });
});

router.post('/stands/:id', requireAuth, (req, res) => {
  const { redirect_url, _method } = req.body;

  // Support method override for PUT via POST
  const method = _method?.toUpperCase();

  if (method === 'DELETE') {
    // Disable stand (soft delete — keeps audit trail)
    const stand = db.prepare(
      'SELECT id FROM stands WHERE id = ? AND user_id = ?'
    ).get(req.params.id, req.session.user.id);

    if (!stand) return res.status(404).render('404');

    db.prepare("UPDATE stands SET status = 'disabled' WHERE id = ?").run(stand.id);
    req.flash('success', 'Stand disabled.');
    return res.redirect('/dashboard');
  }

  // PUT — update redirect URL
  if (!redirect_url?.trim()) {
    req.flash('error', 'Redirect URL is required.');
    return res.redirect(`/stands/${req.params.id}/edit`);
  }

  try {
    const url = new URL(redirect_url.trim());
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error();
  } catch {
    req.flash('error', 'Please enter a valid URL starting with http:// or https://');
    return res.redirect(`/stands/${req.params.id}/edit`);
  }

  const stand = db.prepare(
    'SELECT id FROM stands WHERE id = ? AND user_id = ?'
  ).get(req.params.id, req.session.user.id);

  if (!stand) return res.status(404).render('404');

  db.prepare('UPDATE stands SET redirect_url = ? WHERE id = ?')
    .run(redirect_url.trim(), stand.id);

  req.flash('success', 'Redirect URL updated.');
  res.redirect('/dashboard');
});

// ─── QR code download (per-stand, user-facing) ───────────────────────────────

router.get('/stands/:id/qr', requireAuth, async (req, res) => {
  const stand = db.prepare(
    'SELECT id FROM stands WHERE id = ? AND user_id = ?'
  ).get(req.params.id, req.session.user.id);

  if (!stand) return res.status(404).render('404');

  const standUrl = `${process.env.APP_URL || 'http://localhost:3000'}/s/${stand.id}`;
  try {
    const png = await QRCode.toBuffer(standUrl, {
      type:                 'png',
      width:                1200,
      margin:               2,
      errorCorrectionLevel: 'H',
      color: { dark: '#000000', light: '#FFFFFF' },
    });

    res.set({
      'Content-Type':        'image/png',
      'Content-Disposition': `attachment; filename="stand-${stand.id}-qr.png"`,
      'Cache-Control':       'no-store',
    });
    res.send(png);
  } catch (err) {
    console.error('QR generation failed:', err);
    req.flash('error', 'QR code generation failed.');
    res.redirect('/dashboard');
  }
});

module.exports = router;

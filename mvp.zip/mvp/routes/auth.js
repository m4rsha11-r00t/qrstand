'use strict';

const express   = require('express');
const bcrypt    = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const db        = require('../database/db');
const { redirectIfAuth } = require('../middleware/auth');

const router = express.Router();

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max:      15,
  handler:  (req, res) => {
    req.flash('error', 'Too many attempts. Please try again in 15 minutes.');
    res.redirect(req.path);
  },
});

// ─── Register ──────────────────────────────────────────────────────────────────

router.get('/register', redirectIfAuth, (req, res) => {
  res.render('auth/register', {
    title:        'Create Account',
    prefill_code: req.query.code || '',
  });
});

router.post('/register', authLimiter, redirectIfAuth, (req, res) => {
  const { name, email, password, password_confirm, stand_code } = req.body;

  if (!name?.trim() || !email?.trim() || !password || !stand_code?.trim()) {
    req.flash('error', 'All fields are required, including your stand code.');
    return res.redirect('/register');
  }

  if (password !== password_confirm) {
    req.flash('error', 'Passwords do not match.');
    return res.redirect('/register');
  }

  if (password.length < 8) {
    req.flash('error', 'Password must be at least 8 characters.');
    return res.redirect('/register');
  }

  const stand = db.prepare(
    "SELECT id, token FROM stands WHERE activation_code = ? AND status = 'unactivated'"
  ).get(stand_code.trim().toUpperCase());

  if (!stand) {
    req.flash('error', 'Invalid or already-used stand code. Check the code printed under your stand.');
    return res.redirect('/register');
  }

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.trim().toLowerCase());
  if (existing) {
    req.flash('error', 'An account with that email already exists.');
    return res.redirect('/register');
  }

  const hash   = bcrypt.hashSync(password, 12);
  const result = db.prepare(
    'INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)'
  ).run(name.trim(), email.trim().toLowerCase(), hash);

  const user = db.prepare(
    'SELECT id, name, email, is_admin FROM users WHERE id = ?'
  ).get(result.lastInsertRowid);

  req.session.user = user;

  req.flash('success', `Welcome, ${user.name}! Now activate your stand below.`);
  res.redirect(`/activate?token=${stand.token}`);
});

// ─── Login ─────────────────────────────────────────────────────────────────────

router.get('/login', redirectIfAuth, (req, res) => {
  res.render('auth/login', { title: 'Log In', next: req.query.next || '' });
});

router.post('/login', authLimiter, redirectIfAuth, (req, res) => {
  const { email, password, next } = req.body;

  if (!email?.trim() || !password) {
    req.flash('error', 'Email and password are required.');
    return res.redirect('/login');
  }

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.trim().toLowerCase());

  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    req.flash('error', 'Invalid email or password.');
    return res.redirect('/login');
  }

  req.session.user = {
    id:       user.id,
    name:     user.name,
    email:    user.email,
    is_admin: user.is_admin,
  };

  if (next && next.startsWith('/') && !next.startsWith('//')) {
    return res.redirect(next);
  }

  res.redirect(user.is_admin ? '/admin' : '/dashboard');
});

// ─── Logout ────────────────────────────────────────────────────────────────────

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

module.exports = router;

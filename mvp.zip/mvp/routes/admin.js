'use strict';

const express = require('express');
const QRCode  = require('qrcode');
const crypto  = require('crypto');
const db      = require('../database/db');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.use(requireAdmin);

// ─── Dashboard ────────────────────────────────────────────────────────────────

router.get('/', (req, res) => {
  const totalUsers  = db.prepare('SELECT COUNT(*) AS c FROM users WHERE is_admin = 0').get().c;
  const totalStands = db.prepare('SELECT COUNT(*) AS c FROM stands').get().c;
  const active      = db.prepare("SELECT COUNT(*) AS c FROM stands WHERE status = 'active'").get().c;
  const unactivated = db.prepare("SELECT COUNT(*) AS c FROM stands WHERE status = 'unactivated'").get().c;

  res.render('admin/index', {
    title: 'Admin Dashboard',
    stats: { totalUsers, totalStands, active, unactivated },
  });
});

// ─── Users ────────────────────────────────────────────────────────────────────

router.get('/users', (req, res) => {
  const search = req.query.search?.trim() || '';
  const users = search
    ? db.prepare(`
        SELECT u.*, COUNT(s.id) AS stand_count
        FROM users u
        LEFT JOIN stands s ON s.user_id = u.id
        WHERE u.is_admin = 0 AND (u.name LIKE ? OR u.email LIKE ?)
        GROUP BY u.id ORDER BY u.created_at DESC
      `).all(`%${search}%`, `%${search}%`)
    : db.prepare(`
        SELECT u.*, COUNT(s.id) AS stand_count
        FROM users u
        LEFT JOIN stands s ON s.user_id = u.id
        WHERE u.is_admin = 0
        GROUP BY u.id ORDER BY u.created_at DESC
      `).all();

  res.render('admin/users', { title: 'Users', users, search });
});

router.post('/users/:id/delete', (req, res) => {
  db.prepare('DELETE FROM users WHERE id = ? AND is_admin = 0').run(req.params.id);
  req.flash('success', 'User deleted.');
  res.redirect('/admin/users');
});

// ─── Stands ───────────────────────────────────────────────────────────────────

router.get('/stands', (req, res) => {
  const search = req.query.search?.trim() || '';
  const stands = search
    ? db.prepare(`
        SELECT s.*, u.name AS user_name, u.email AS user_email
        FROM stands s
        LEFT JOIN users u ON u.id = s.user_id
        WHERE s.activation_code LIKE ? OR u.name LIKE ? OR u.email LIKE ?
        ORDER BY s.created_at DESC
      `).all(`%${search}%`, `%${search}%`, `%${search}%`)
    : db.prepare(`
        SELECT s.*, u.name AS user_name, u.email AS user_email
        FROM stands s
        LEFT JOIN users u ON u.id = s.user_id
        ORDER BY s.created_at DESC
      `).all();

  res.render('admin/stands', { title: 'Stands', stands, search });
});

// Toggle active / disabled
router.post('/stands/:id/toggle', (req, res) => {
  const stand = db.prepare('SELECT id, status FROM stands WHERE id = ?').get(req.params.id);
  if (!stand) return res.status(404).render('404');

  const newStatus = stand.status === 'active' ? 'disabled' : 'active';
  db.prepare('UPDATE stands SET status = ? WHERE id = ?').run(newStatus, stand.id);

  req.flash('success', `Stand ${newStatus === 'active' ? 'enabled' : 'disabled'}.`);
  res.redirect('/admin/stands');
});

// Reset stand — clears user link, URL, status back to unactivated
router.post('/stands/:id/reset', (req, res) => {
  db.prepare(`
    UPDATE stands
    SET user_id      = NULL,
        redirect_url = NULL,
        status       = 'unactivated',
        activated_at = NULL
    WHERE id = ?
  `).run(req.params.id);

  req.flash('success', 'Stand reset to unactivated.');
  res.redirect('/admin/stands');
});

// ─── Add activation codes (bulk import) ──────────────────────────────────────
// POST body: { codes: "CODE1\nCODE2\nCODE3" }

router.get('/stands/add', (req, res) => {
  res.render('admin/add-codes', { title: 'Add Activation Codes' });
});

router.post('/stands/add', (req, res) => {
  const raw = req.body.codes || '';
  const codes = raw
    .split(/[\n,]+/)
    .map(c => c.trim().toUpperCase())
    .filter(c => c.length > 0);

  if (codes.length === 0) {
    req.flash('error', 'No codes provided.');
    return res.redirect('/admin/stands/add');
  }

  const insert = db.prepare(
    'INSERT OR IGNORE INTO stands (activation_code, token) VALUES (?, ?)'
  );

  let added = 0;
  const insertMany = db.transaction((codes) => {
    for (const code of codes) {
      const info = insert.run(code, crypto.randomBytes(8).toString('hex'));
      if (info.changes) added++;
    }
  });

  insertMany(codes);

  req.flash('success', `${added} code(s) added. ${codes.length - added} duplicate(s) skipped.`);
  res.redirect('/admin/stands');
});

// ─── Universal QR code download ───────────────────────────────────────────────

router.get('/qr-code', async (req, res) => {
  const scanUrl = `${process.env.APP_URL || 'http://localhost:3000'}/scan`;
  try {
    const png = await QRCode.toBuffer(scanUrl, {
      type:           'png',
      width:          1200,
      margin:         2,
      errorCorrectionLevel: 'H',
      color: { dark: '#000000', light: '#FFFFFF' },
    });

    res.set({
      'Content-Type':        'image/png',
      'Content-Disposition': 'attachment; filename="qrstand-universal.png"',
      'Cache-Control':       'no-store',
    });
    res.send(png);
  } catch (err) {
    console.error('QR generation failed:', err);
    req.flash('error', 'QR code generation failed.');
    res.redirect('/admin');
  }
});

// Per-stand QR code (points to /s/:token — unique per stand)
router.get('/stands/:id/qr', async (req, res) => {
  const stand = db.prepare('SELECT id, token FROM stands WHERE id = ?').get(req.params.id);
  if (!stand) return res.status(404).render('404', { title: 'Not found' });

  const standUrl = `${process.env.APP_URL || 'http://localhost:3000'}/s/${stand.token}`;
  try {
    const png = await QRCode.toBuffer(standUrl, {
      type:           'png',
      width:          1200,
      margin:         2,
      errorCorrectionLevel: 'H',
      color: { dark: '#000000', light: '#FFFFFF' },
    });

    res.set({
      'Content-Type':        'image/png',
      'Content-Disposition': `attachment; filename="stand-${stand.id}-qr.png"`,
      'Cache-Control':       'no-store',
    });
    res.send(png);
  } catch (err) {
    console.error('QR generation failed:', err);
    req.flash('error', 'QR code generation failed.');
    res.redirect('/admin/stands');
  }
});

module.exports = router;

'use strict';

const express  = require('express');
const QRCode   = require('qrcode');
const crypto   = require('crypto');
const archiver = require('archiver');
const db       = require('../database/db');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.use(requireAdmin);

// ─── Dashboard ────────────────────────────────────────────────────────────────

router.get('/', (req, res) => {
  const totalUsers  = db.prepare('SELECT COUNT(*) AS c FROM users WHERE is_admin = 0').get().c;
  const totalStands = db.prepare('SELECT COUNT(*) AS c FROM stands').get().c;
  const active      = db.prepare("SELECT COUNT(*) AS c FROM stands WHERE status = 'active'").get().c;
  const unactivated = db.prepare("SELECT COUNT(*) AS c FROM stands WHERE status = 'unactivated'").get().c;
  const totalBatches = db.prepare(
    "SELECT COUNT(DISTINCT batch_name) AS c FROM stands WHERE batch_name IS NOT NULL"
  ).get().c;

  res.render('admin/index', {
    title: 'Admin Dashboard',
    stats: { totalUsers, totalStands, active, unactivated, totalBatches },
  });
});

// ─── Users ────────────────────────────────────────────────────────────────────

router.get('/users', (req, res) => {
  const search = req.query.search?.trim() || '';
  const users = search
    ? db.prepare(`
        SELECT u.*, COUNT(s.id) AS stand_count
        FROM users u LEFT JOIN stands s ON s.user_id = u.id
        WHERE u.is_admin = 0 AND (u.name LIKE ? OR u.email LIKE ?)
        GROUP BY u.id ORDER BY u.created_at DESC
      `).all(`%${search}%`, `%${search}%`)
    : db.prepare(`
        SELECT u.*, COUNT(s.id) AS stand_count
        FROM users u LEFT JOIN stands s ON s.user_id = u.id
        WHERE u.is_admin = 0
        GROUP BY u.id ORDER BY u.created_at DESC
      `).all();

  res.render('admin/users', { title: 'Users', users, search });
});

router.post('/users/:id/delete', (req, res) => {
  db.prepare('DELETE FROM users WHERE id = ? AND is_admin = 0').run(req.params.id);
  req.flash('success', 'User deleted.');
  res.redirect('/admin/users');
});

// ─── Stands ───────────────────────────────────────────────────────────────────

router.get('/stands', (req, res) => {
  const search    = req.query.search?.trim() || '';
  const batch     = req.query.batch?.trim() || '';

  let query = `
    SELECT s.*, u.name AS user_name, u.email AS user_email
    FROM stands s LEFT JOIN users u ON u.id = s.user_id
    WHERE 1=1
  `;
  const params = [];

  if (batch) {
    query += ' AND s.batch_name = ?';
    params.push(batch);
  }
  if (search) {
    query += ' AND (s.activation_code LIKE ? OR u.name LIKE ? OR u.email LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }

  query += ' ORDER BY s.created_at DESC';

  const stands = db.prepare(query).all(...params);

  res.render('admin/stands', { title: 'Stands', stands, search, batch });
});

router.post('/stands/:id/toggle', (req, res) => {
  const stand = db.prepare('SELECT id, status FROM stands WHERE id = ?').get(req.params.id);
  if (!stand) return res.status(404).render('404', { title: 'Not found' });

  const newStatus = stand.status === 'active' ? 'disabled' : 'active';
  db.prepare('UPDATE stands SET status = ? WHERE id = ?').run(newStatus, stand.id);

  req.flash('success', `Stand ${newStatus === 'active' ? 'enabled' : 'disabled'}.`);
  res.redirect('back');
});

router.post('/stands/:id/reset', (req, res) => {
  db.prepare(`
    UPDATE stands SET user_id = NULL, redirect_url = NULL,
    status = 'unactivated', activated_at = NULL WHERE id = ?
  `).run(req.params.id);

  req.flash('success', 'Stand reset to unactivated.');
  res.redirect('back');
});

// ─── Add activation codes (single / manual) ───────────────────────────────────

router.get('/stands/add', (req, res) => {
  res.render('admin/add-codes', { title: 'Add Activation Codes' });
});

router.post('/stands/add', (req, res) => {
  const raw   = req.body.codes || '';
  const codes = raw.split(/[\n,]+/).map(c => c.trim().toUpperCase()).filter(Boolean);

  if (codes.length === 0) {
    req.flash('error', 'No codes provided.');
    return res.redirect('/admin/stands/add');
  }

  const insert = db.prepare(
    'INSERT OR IGNORE INTO stands (activation_code, token) VALUES (?, ?)'
  );

  let added = 0;
  db.transaction(() => {
    for (const code of codes) {
      const info = insert.run(code, crypto.randomBytes(8).toString('hex'));
      if (info.changes) added++;
    }
  })();

  req.flash('success', `${added} code(s) added. ${codes.length - added} duplicate(s) skipped.`);
  res.redirect('/admin/stands');
});

// ─── Batches ──────────────────────────────────────────────────────────────────

router.get('/batches', (req, res) => {
  const search = req.query.search?.trim() || '';

  const batches = search
    ? db.prepare(`
        SELECT batch_name,
               COUNT(*) AS quantity,
               SUM(CASE WHEN status = 'active'      THEN 1 ELSE 0 END) AS active_count,
               SUM(CASE WHEN status = 'unactivated' THEN 1 ELSE 0 END) AS unactivated_count,
               MIN(created_at) AS created_at
        FROM stands WHERE batch_name IS NOT NULL AND batch_name LIKE ?
        GROUP BY batch_name ORDER BY MIN(created_at) DESC
      `).all(`%${search}%`)
    : db.prepare(`
        SELECT batch_name,
               COUNT(*) AS quantity,
               SUM(CASE WHEN status = 'active'      THEN 1 ELSE 0 END) AS active_count,
               SUM(CASE WHEN status = 'unactivated' THEN 1 ELSE 0 END) AS unactivated_count,
               MIN(created_at) AS created_at
        FROM stands WHERE batch_name IS NOT NULL
        GROUP BY batch_name ORDER BY MIN(created_at) DESC
      `).all();

  res.render('admin/batches', { title: 'Batches', batches, search });
});

router.get('/batches/new', (req, res) => {
  res.render('admin/batch-new', { title: 'Generate Batch' });
});

router.post('/batches', (req, res) => {
  const { batch_name, quantity, prefix } = req.body;

  if (!batch_name?.trim()) {
    req.flash('error', 'Batch name is required.');
    return res.redirect('/admin/batches/new');
  }

  const qty = parseInt(quantity, 10);
  if (!qty || qty < 1 || qty > 10000) {
    req.flash('error', 'Quantity must be between 1 and 10,000.');
    return res.redirect('/admin/batches/new');
  }

  const pfx  = (prefix || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  const name = batch_name.trim();

  // Load existing codes with this prefix to avoid collisions
  const existingCodes = new Set(
    db.prepare('SELECT activation_code FROM stands WHERE activation_code LIKE ?')
      .all(`${pfx}%`)
      .map(r => r.activation_code)
  );

  // Load existing tokens to avoid collisions
  const existingTokens = new Set(
    db.prepare('SELECT token FROM stands WHERE token IS NOT NULL')
      .all()
      .map(r => r.token)
  );

  // Generate sequential activation codes, skipping any that already exist
  const codes = [];
  let seq = 1;
  while (codes.length < qty) {
    const code = pfx + String(seq).padStart(6, '0');
    if (!existingCodes.has(code)) codes.push(code);
    seq++;
    if (seq > qty * 10 + 1000) break; // safety cap
  }

  if (codes.length < qty) {
    req.flash('error', 'Could not generate enough unique codes. Try a different prefix.');
    return res.redirect('/admin/batches/new');
  }

  // Generate unique tokens
  const tokens = [];
  while (tokens.length < qty) {
    const token = crypto.randomBytes(8).toString('hex');
    if (!existingTokens.has(token)) {
      tokens.push(token);
      existingTokens.add(token);
    }
  }

  // Bulk insert in single transaction
  const insert = db.prepare(
    'INSERT INTO stands (activation_code, token, batch_name) VALUES (?, ?, ?)'
  );

  db.transaction(() => {
    for (let i = 0; i < qty; i++) {
      insert.run(codes[i], tokens[i], name);
    }
  })();

  req.flash('success', `Batch "${name}" created with ${qty} stands.`);
  res.redirect('/admin/batches');
});

// Download batch as ZIP (QR PNGs + CSV)
router.get('/batches/:batchName/download', async (req, res) => {
  const batchName = req.params.batchName;

  const stands = db.prepare(
    'SELECT id, activation_code, token, status FROM stands WHERE batch_name = ? ORDER BY activation_code ASC'
  ).all(batchName);

  if (stands.length === 0) {
    req.flash('error', 'Batch not found or empty.');
    return res.redirect('/admin/batches');
  }

  const appUrl  = process.env.APP_URL || 'http://localhost:3000';
  const safeName = batchName.replace(/[^a-zA-Z0-9-_]/g, '_');

  res.set({
    'Content-Type':        'application/zip',
    'Content-Disposition': `attachment; filename="batch-${safeName}.zip"`,
    'Cache-Control':       'no-store',
  });

  const archive = archiver('zip', { zlib: { level: 1 } });
  archive.on('error', err => { throw err; });
  archive.pipe(res);

  // CSV
  const lines = ['activation_code,token,qr_url,batch_name,status'];
  for (const s of stands) {
    lines.push(`${s.activation_code},${s.token},${appUrl}/s/${s.token},${batchName},${s.status}`);
  }
  archive.append(lines.join('\n') + '\n', { name: `batch_${safeName}/stands.csv` });

  // QR PNGs — parallel in chunks of 50 to balance speed vs memory
  const CHUNK = 50;
  for (let i = 0; i < stands.length; i += CHUNK) {
    const chunk = stands.slice(i, i + CHUNK);
    const pngs  = await Promise.all(
      chunk.map(s => QRCode.toBuffer(`${appUrl}/s/${s.token}`, {
        type:                 'png',
        width:                800,
        margin:               2,
        errorCorrectionLevel: 'H',
        color: { dark: '#000000', light: '#FFFFFF' },
      }))
    );
    pngs.forEach((png, j) => {
      archive.append(png, { name: `batch_${safeName}/qr/${chunk[j].activation_code}.png` });
    });
  }

  await archive.finalize();
});

// ─── Universal QR code download ───────────────────────────────────────────────

router.get('/qr-code', async (req, res) => {
  const scanUrl = `${process.env.APP_URL || 'http://localhost:3000'}/scan`;
  try {
    const png = await QRCode.toBuffer(scanUrl, {
      type: 'png', width: 1200, margin: 2, errorCorrectionLevel: 'H',
      color: { dark: '#000000', light: '#FFFFFF' },
    });
    res.set({
      'Content-Type':        'image/png',
      'Content-Disposition': 'attachment; filename="qrstand-universal.png"',
      'Cache-Control':       'no-store',
    });
    res.send(png);
  } catch (err) {
    console.error('QR generation failed:', err);
    req.flash('error', 'QR code generation failed.');
    res.redirect('/admin');
  }
});

// Per-stand QR code (points to /s/:token)
router.get('/stands/:id/qr', async (req, res) => {
  const stand = db.prepare('SELECT id, token FROM stands WHERE id = ?').get(req.params.id);
  if (!stand) return res.status(404).render('404', { title: 'Not found' });

  const standUrl = `${process.env.APP_URL || 'http://localhost:3000'}/s/${stand.token}`;
  try {
    const png = await QRCode.toBuffer(standUrl, {
      type: 'png', width: 1200, margin: 2, errorCorrectionLevel: 'H',
      color: { dark: '#000000', light: '#FFFFFF' },
    });
    res.set({
      'Content-Type':        'image/png',
      'Content-Disposition': `attachment; filename="stand-${stand.id}-qr.png"`,
      'Cache-Control':       'no-store',
    });
    res.send(png);
  } catch (err) {
    console.error('QR generation failed:', err);
    req.flash('error', 'QR code generation failed.');
    res.redirect('/admin/stands');
  }
});

module.exports = router;

'use strict';

const express = require('express');
const bcrypt  = require('bcryptjs');
const db      = require('../database/db');

const router = express.Router();

// ─── Batch join landing ────────────────────────────────────────────────────────
// Public URL shared by the business with clients: /join/:batchName
// No activation code needed — system auto-assigns the next available stand.
//
// Flow:
//   Not logged in  → show register/login form
//   Logged in      → show "enter your URL" form
//   POST           → assign next unactivated stand, redirect to dashboard

router.get('/join/:batchName', (req, res) => {
  const batch = req.params.batchName;

  const available = db.prepare(
    "SELECT COUNT(*) AS c FROM stands WHERE batch_name = ? AND status = 'unactivated' AND user_id IS NULL"
  ).get(batch).c;

  if (!available) {
    return res.render('join/unavailable', { title: 'No Stands Available', batch });
  }

  if (req.session.user) {
    return res.render('join/setup', { title: 'Set Up Your Stand', batch });
  }

  res.render('join/landing', { title: 'Get Your QR Stand', batch });
});

// ─── Logged-in user: enter destination URL and claim a stand ──────────────────

router.post('/join/:batchName', (req, res) => {
  const batch       = req.params.batchName;
  const { redirect_url, name, email, password } = req.body;

  // If not logged in, register inline
  if (!req.session.user) {
    if (!name?.trim() || !email?.trim() || !password) {
      req.flash('error', 'Name, email and password are required.');
      return res.redirect(`/join/${batch}`);
    }
    if (password.length < 8) {
      req.flash('error', 'Password must be at least 8 characters.');
      return res.redirect(`/join/${batch}`);
    }
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.trim().toLowerCase());
    if (existing) {
      req.flash('error', 'An account with that email already exists. Please log in.');
      return res.redirect(`/login?next=/join/${batch}`);
    }
    const hash   = bcrypt.hashSync(password, 12);
    const result = db.prepare(
      'INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)'
    ).run(name.trim(), email.trim().toLowerCase(), hash);
    const user = db.prepare('SELECT id, name, email, is_admin FROM users WHERE id = ?').get(result.lastInsertRowid);
    req.session.user = user;
  }

  // Validate URL
  if (!redirect_url?.trim()) {
    req.flash('error', 'Destination URL is required.');
    return res.redirect(`/join/${batch}`);
  }
  try {
    const url = new URL(redirect_url.trim());
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error();
  } catch {
    req.flash('error', 'Please enter a valid URL starting with http:// or https://');
    return res.redirect(`/join/${batch}`);
  }

  // Claim next available stand from batch (atomic — no double-assignment)
  const stand = db.prepare(`
    SELECT id, token FROM stands
    WHERE batch_name = ? AND status = 'unactivated' AND user_id IS NULL
    LIMIT 1
  `).get(batch);

  if (!stand) {
    req.flash('error', 'Sorry, no stands are available in this batch.');
    return res.redirect(`/join/${batch}`);
  }

  db.prepare(`
    UPDATE stands
    SET user_id = ?, redirect_url = ?, status = 'active', activated_at = CURRENT_TIMESTAMP
    WHERE id = ? AND status = 'unactivated' AND user_id IS NULL
  `).run(req.session.user.id, redirect_url.trim(), stand.id);

  req.flash('success', 'Your stand is ready! Download your QR code below.');
  res.redirect('/dashboard');
});

module.exports = router;

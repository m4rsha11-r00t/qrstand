'use strict';

const express = require('express');
const db      = require('../database/db');

const router = express.Router();

// ─── Universal QR scan entry point ────────────────────────────────────────────
// All physical stands share one QR code pointing here.
// If the user is logged in, take them to activate.
// If not, show the landing page with login/register options.

router.get('/scan', (req, res) => {
  if (req.session.user) {
    return res.redirect('/activate');
  }
  res.render('scan', { title: 'Activate Your Stand' });
});

// ─── Per-stand redirect ────────────────────────────────────────────────────────
// After activation, each stand gets a unique URL: /s/:id
// This is what the final QR code (downloaded from the dashboard) points to.

router.get('/s/:id', (req, res) => {
  const stand = db.prepare(
    'SELECT id, redirect_url, status FROM stands WHERE id = ?'
  ).get(req.params.id);

  if (!stand) {
    return res.status(404).render('404');
  }

  if (stand.status === 'active' && stand.redirect_url) {
    return res.redirect(302, stand.redirect_url);
  }

  // Not activated or disabled
  res.redirect('/scan');
});

module.exports = router;

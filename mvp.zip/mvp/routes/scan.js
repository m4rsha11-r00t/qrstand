'use strict';

const express = require('express');
const db      = require('../database/db');

const router = express.Router();

// ─── Root redirect ─────────────────────────────────────────────────────────────

router.get('/', (req, res) => res.redirect('/scan'));

// ─── Generic scan landing (no stand context) ───────────────────────────────────

router.get('/scan', (req, res) => {
  if (req.session.user) return res.redirect('/activate');
  res.render('scan', { title: 'Activate Your Stand' });
});

// ─── Per-stand entry point ─────────────────────────────────────────────────────
// Each physical stand has a unique QR that encodes: APP_URL/s/:token
//
// Behaviour:
//   active      → 302 redirect to stored URL
//   unactivated → redirect to /activate?token=TOKEN so the form is pre-linked
//   disabled    → show scan landing (inactive message)

router.get('/s/:token', (req, res) => {
  const stand = db.prepare(
    'SELECT id, redirect_url, status FROM stands WHERE token = ?'
  ).get(req.params.token);

  if (!stand) return res.status(404).render('404', { title: 'Not found' });

  if (stand.status === 'active' && stand.redirect_url) {
    return res.redirect(302, stand.redirect_url);
  }

  if (stand.status === 'unactivated') {
    const dest = req.session.user
      ? `/activate?token=${req.params.token}`
      : `/login?next=/activate?token=${req.params.token}`;
    return res.redirect(dest);
  }

  // disabled
  res.render('scan', { title: 'Stand Inactive' });
});

module.exports = router;

# QRStand MVP — DigitalOcean Deployment Runbook

Target: Ubuntu 24.04 LTS droplet, IP-based (no domain, no SSL), port 80.

---

## Prerequisites

- DigitalOcean droplet: Ubuntu 24.04 LTS, minimum 1 GB RAM
- You have the root password or SSH key
- Your server IP address (referred to below as `YOUR_SERVER_IP`)

---

## PHASE 1 — Initial server access

```
# From your local machine
ssh root@YOUR_SERVER_IP
```

---

## PHASE 2 — System update

```
apt update && apt upgrade -y
apt install -y curl git ufw
```

---

## PHASE 3 — Create a sudo user

```
adduser deploy
usermod -aG sudo deploy
```

Set a strong password when prompted.

Copy your SSH key to the new user (run from your LOCAL machine):

```
ssh-copy-id deploy@YOUR_SERVER_IP
```

Verify you can log in:

```
ssh deploy@YOUR_SERVER_IP
```

From now on, all commands run as `deploy` (not root).

---

## PHASE 4 — SSH hardening

```
sudo nano /etc/ssh/sshd_config
```

Find and set (or add) these lines:

```
PermitRootLogin no
PasswordAuthentication no
```

Save and restart SSH:

```
sudo systemctl restart ssh
```

> **Do not close your current session** until you confirm the new session works.

Open a new terminal and test:

```
ssh deploy@YOUR_SERVER_IP
```

---

## PHASE 5 — Firewall

```
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw --force enable
sudo ufw status
```

Expected output includes: `22/tcp ALLOW`, `80/tcp ALLOW`.

---

## PHASE 6 — Install Node.js 20

```
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node -v    # should print v20.x.x
npm -v
```

---

## PHASE 7 — Install PM2

```
sudo npm install -g pm2
pm2 -v
```

---

## PHASE 8 — Install Nginx

```
sudo apt install -y nginx
sudo systemctl enable nginx
sudo systemctl start nginx
```

Verify: open `http://YOUR_SERVER_IP` in a browser — you should see the Nginx welcome page.

---

## PHASE 9 — Upload the application

### Option A — Git (recommended)

```
cd /home/deploy
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git qrstand
cd qrstand/mvp
```

### Option B — SCP (from your local machine)

```
scp -r ./mvp deploy@YOUR_SERVER_IP:/home/deploy/qrstand
```

---

## PHASE 10 — Install dependencies

```
cd /home/deploy/qrstand/mvp
npm install --omit=dev
```

---

## PHASE 11 — Create the .env file

```
nano /home/deploy/qrstand/mvp/.env
```

Paste and fill in:

```
NODE_ENV=production
PORT=3000
APP_URL=http://YOUR_SERVER_IP
SESSION_SECRET=REPLACE_WITH_64_RANDOM_CHARS
DB_PATH=/home/deploy/qrstand/data/qrstand.db
ADMIN_NAME=Admin
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=REPLACE_WITH_STRONG_PASSWORD_12_CHARS_MIN
```

Generate a secure SESSION_SECRET:

```
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Paste the output as the SESSION_SECRET value.

---

## PHASE 12 — Create the data directory

```
mkdir -p /home/deploy/qrstand/data
```

---

## PHASE 13 — Seed the admin account

```
cd /home/deploy/qrstand/mvp
node scripts/seed-admin.js
```

Expected output: `Admin created: admin@example.com`

---

## PHASE 14 — Start the application with PM2

```
cd /home/deploy/qrstand/mvp
pm2 start app.js --name qrstand
pm2 save
pm2 startup
```

The `pm2 startup` command prints a `sudo env PATH=...` command. Copy it and run it. This makes the app start automatically on reboot.

Verify the app is running:

```
pm2 status
pm2 logs qrstand --lines 20
```

The app should show `online` status with no errors.

---

## PHASE 15 — Configure Nginx as reverse proxy

```
sudo nano /etc/nginx/sites-available/qrstand
```

Paste exactly:

```nginx
server {
    listen 80;
    server_name _;

    client_max_body_size 2M;

    location / {
        proxy_pass         http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header   Upgrade $http_upgrade;
        proxy_set_header   Connection 'upgrade';
        proxy_set_header   Host $host;
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site and remove the default:

```
sudo ln -s /etc/nginx/sites-available/qrstand /etc/nginx/sites-enabled/qrstand
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
```

`nginx -t` must print: `syntax is ok` and `test is successful`.

---

## PHASE 16 — Verify the deployment

Open `http://YOUR_SERVER_IP` in a browser.

Checklist:
- [ ] Homepage loads (scan landing page)
- [ ] `/register` page loads
- [ ] `/login` page loads
- [ ] Log in with the admin credentials from .env
- [ ] Admin dashboard shows at `/admin`
- [ ] Add one activation code via `/admin/stands/add`
- [ ] Log out, register a test user account
- [ ] Activate the stand using the code you just added
- [ ] Confirm the stand appears on the dashboard
- [ ] Download the QR code for the stand
- [ ] Test the QR link: `http://YOUR_SERVER_IP/s/1` — should redirect

---

## PHASE 17 — Set file permissions

```
chmod 600 /home/deploy/qrstand/mvp/.env
chmod 700 /home/deploy/qrstand/data
```

---

## PHASE 18 — Automatic SQLite backup (daily)

```
mkdir -p /home/deploy/backups

crontab -e
```

Add this line:

```
0 2 * * * cp /home/deploy/qrstand/data/qrstand.db /home/deploy/backups/qrstand-$(date +\%Y\%m\%d).db
```

Keep 30 days of backups (add second line):

```
0 3 * * * find /home/deploy/backups -name "qrstand-*.db" -mtime +30 -delete
```

---

## PHASE 19 — Redeployment procedure

When you push new code:

```
cd /home/deploy/qrstand/mvp
git pull
npm install --omit=dev
pm2 reload qrstand
```

Verify:

```
pm2 status
pm2 logs qrstand --lines 30
```

---

## Logs and troubleshooting

| What                  | Command                                  |
|-----------------------|------------------------------------------|
| App logs (live)       | `pm2 logs qrstand`                       |
| App logs (last 100)   | `pm2 logs qrstand --lines 100`           |
| App status            | `pm2 status`                             |
| Restart app           | `pm2 restart qrstand`                    |
| Stop app              | `pm2 stop qrstand`                       |
| Nginx error log       | `sudo tail -f /var/log/nginx/error.log`  |
| Nginx access log      | `sudo tail -f /var/log/nginx/access.log` |
| Nginx config test     | `sudo nginx -t`                          |
| Reload Nginx          | `sudo systemctl reload nginx`            |
| Check port 3000       | `ss -tlnp \| grep 3000`                  |
| Check firewall        | `sudo ufw status`                        |

---

## Common issues

**App shows 502 Bad Gateway**
The Node app is not running on port 3000.
```
pm2 status
pm2 logs qrstand --lines 50
```
Fix any startup errors shown in the logs, then `pm2 restart qrstand`.

**pm2 startup command not run**
After `pm2 startup`, you must run the printed `sudo env PATH=...` command, then `pm2 save` again.

**Session not persisting after restart**
Ensure `SESSION_SECRET` in `.env` is set to a fixed value (not regenerated each deploy).

**Database not found**
Check `DB_PATH` in `.env` points to an existing directory. Run `mkdir -p /home/deploy/qrstand/data`.

**Cannot reach the site**
```
sudo ufw status           # port 80 must be ALLOW
sudo systemctl status nginx
pm2 status
```

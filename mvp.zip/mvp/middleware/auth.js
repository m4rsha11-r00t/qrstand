'use strict';

function requireAuth(req, res, next) {
  if (req.session.user) return next();
  req.flash('error', 'Please log in to continue.');
  res.redirect('/login');
}

function requireAdmin(req, res, next) {
  if (req.session.user?.is_admin) return next();
  res.status(403).render('403');
}

function redirectIfAuth(req, res, next) {
  if (req.session.user) return res.redirect('/dashboard');
  next();
}

module.exports = { requireAuth, requireAdmin, redirectIfAuth };
